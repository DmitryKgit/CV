const data = {
    "first_name": "Dmitriy",
    "last_name": "Kapran",
    "job_title": "Junior Frontend Developer",
    "photo": "images/w1.jpg",
    "phone": "+79035768578",
    "email": "kaprandm@gmail.com",
    "skype": "skype_number",
    "linkedin": "link_to_linkedin",
    "address": "m. Rechnoi vokzal, Moscow",
    "skills": [
        "Дисциплинированный",
        "Ответсвенный",
        "Практичный",
        "Напористый",
        "Спокойный",
        "Простой",
        "Человек",
        "HTML",
        "CSS",
        "Javascript",
        "Basic English",
    ],
    "education": [
        ["1997-2007", "Средняя школа №1224 с углублённым изучением английского языка"],
        ["2007-2013", "Московский Энергитический институт"],
    ],
    // "achievements": [
    //     "Marketer of the Year Academic Scholorship Deans List: 2006-2007, National Merit Scholarship Corporation",
    // ],
    "profile": "Мне 30 лет, выполнял только учебные проекты и тестовые задания, без коммерческого опыта в it. 9 лет работаю в проектировании магистральных трубопроводов в Москве. Есть огромное желание сменить профессию на разработчика. Около года изучаю фронтенд. Владею технологиями HTML5/CSS3, адаптивной вёрсткой, Javascript ES6, npm, git, основы React."
};